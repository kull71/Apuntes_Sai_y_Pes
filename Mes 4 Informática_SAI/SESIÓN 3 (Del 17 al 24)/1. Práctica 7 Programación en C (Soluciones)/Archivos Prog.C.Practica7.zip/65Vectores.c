#include <stdio.h>
/* declaracion de funciones */
void suma( double*, double*, double*);
void resta( double*, double*, double*);
void productoVectorial(double*, double*, double*);
double productoEscalar(double*, double*);
int main(void)
{
	double vector1[3], vector2[3], vecsum[3], vecres[3];
	double prodvect[3];
	int i;
	printf("Introduce los valores del primer vector:\n");
	for (i=0; i<3; i++)
	{
		printf("\nElmento %d: ", i+1);
		scanf("%lf", &vector1[i]);
	}
	printf("\n");
	printf("Introduce los valores del segundo vector:\n");

	for (i=0; i<3; i++)
	{
		printf("\nElemento %d: ", i+1);
		scanf("%lf", &vector2[i]);
	}
	printf("\n");
	suma(vector1, vector2, vecsum);
	resta(vector1, vector2, vecres);
	productoVectorial(vector1, vector2, prodvect);
	printf("\nImprimo los resultados: \n\n");
	printf("%10s %10s %20s\n", "Suma", "Resta", "Producto Vectorial");
	for (i=1; i<=50; i++)
		printf("-");
	printf("\n");
	for (i=0; i<3; i++)
	{
		printf("%10.2lf  %10.2lf  %10.2lf\n", vecsum[i], vecres[i], prodvect[i]);
		printf("\n");
	}

	printf("Producto escalar = %5.2lf\n", productoEscalar(vector1,vector2));
	printf("----------------\n");

	return 0;
}
void suma(double* vec1, double* vec2, double* sum)
{
	int i;
	for (i=0; i<3; i++)
		sum[i]=vec1[i]+vec2[i];
	return;
}

void resta(double* vec1, double* vec2, double* res)
{
	int i;
	for (i=0; i<3; i++)
		res[i]=vec1[i]-vec2[i];
	return;
}

void productoVectorial(double* vec1, double* vec2, double* vectorial)
{
	vectorial[0] = vec1[1]*vec2[2]-vec2[1]*vec1[2];
	vectorial[1] = vec1[2]*vec2[0]-vec2[2]*vec1[0];
	vectorial[2] = vec1[0]*vec2[1]-vec2[0]*vec1[1];
	return;
}

double productoEscalar(double* vec1, double* vec2)
{
	double escalar = 0.0;
	int i;
	for (i=0; i<3; i++)
		escalar+=vec1[i]*vec2[i];
	return (escalar);
}
