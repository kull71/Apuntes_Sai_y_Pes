#include <stdio.h>
#include <stdlib.h>

struct elemento
{
	int dato;
	struct elemento *psig;
};

int main()
{
	struct elemento *lista=NULL, *q, *p;
	int num;

	while (1)
	{
		printf("Dame número (CTRL+D=Fin en Linux ó CTRL+Z=Fin en Windows): ");
		if (scanf("%d", &num)==EOF)
			break;
		q = (struct elemento *)malloc(sizeof(struct elemento));

		if (q==NULL)
		{
			printf("ERROR: Falta memoria.\n");
			getchar();
		}
		else
		{
			q->dato=num;
			q->psig=NULL;

			if (lista==NULL)
				lista=q;
			else
			{
				p=lista;

				while (p->psig!=NULL)
					p=p->psig;
					p->psig=q;
			}
		}
	}

	printf("\nLos números introducidos son:\n");
	q=lista;

	while (q!=NULL)
	{
		printf("%d ",q->dato);
		q=q->psig;
	}
	printf("\nEliminando la lista...\n");
	while (lista!=NULL)
		{
			q=lista;
			lista=lista->psig;
			free(q);
		}
	return 0;
}
