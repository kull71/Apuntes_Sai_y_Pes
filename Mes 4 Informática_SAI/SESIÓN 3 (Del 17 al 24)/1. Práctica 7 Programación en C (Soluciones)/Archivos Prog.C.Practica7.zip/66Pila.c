#include <stdio.h>
#include <stdlib.h>

typedef struct datos nodo;

struct datos /* estructura de un elemento de la pila */
{
	double dato;
	nodo *siguiente;
};

/* Prototipos de funciones */
void push(nodo **p, double x); // añadir un dato a la pila
double pop(nodo **p); // sacar un dato de la pila
void error(void);
nodo *nuevo_elemento(void); //reserva dinámica de memoria

int main()
{
	nodo *q,*cima = NULL;
	double a, b;
	char op[81];
	printf("Calculadora con las operaciones: + - ^ /\n");
	printf("Los datos serán introducidos de la forma:\n");
	printf(">operando 1\n");
	printf(">operando 2\n");
	printf("operador\n\n");
	printf("Para salir pulse q\n\n");
	do
	{
		printf("> ");
		gets(op); /* leer un operando o un operador */
		switch (*op)
		{
			case '+' :
				b = pop(&cima);
				a = pop(&cima);
				printf("%g\n", a + b);
				push(&cima, a+b);
				break;
			case '-' :
				b = pop(&cima);
				a = pop(&cima);
				printf("%g\n", a - b);
				push( &cima, a-b);
				break;
			case '*':
				b = pop(&cima);
				a = pop(&cima);
				printf("%g\n", a * b);
				push( &cima, a*b);
				break;
			case '/':
				b = pop(&cima);
				a = pop(&cima);
				if(b==0)
				{
					printf("Division por CERO");
					break;
				}
				printf("%g\n", a / b);
				push( &cima, a/b);
				break;
			default:
				push(&cima, atof(op));
		}
	}

	while(*op != 'q');
	//liberamos memoria
		q = cima;
	while(q != NULL)
	{
		cima = cima->siguiente;
		free (q);
		q = cima;
	}
} //fin de main()


/*Añadir un dato a la pila*/
void push(nodo **p, double x)
{
	nodo *q, *cima;
	cima = *p;
	q = nuevo_elemento();
	q->dato = x;
	q->siguiente = cima;
	cima = q;
	*p=cima;
}
//recuperar de la cima
double pop(nodo **p)

{
	nodo *cima;
	double x;
	cima= *p;
	if(cima ==NULL)
	{
		printf("ERRRRORRRRR");
		return 0;
	}
	else
	{
		x=cima->dato;
		*p=cima->siguiente;
		free(cima);
		return x;
	}
}
void error(void)

{
	perror("Mem no reservada");
	exit(0);
}

nodo *nuevo_elemento(void)

{
	nodo *q = (nodo *)malloc(sizeof(nodo));
	if(!q)
		error();
	return (q);
}
