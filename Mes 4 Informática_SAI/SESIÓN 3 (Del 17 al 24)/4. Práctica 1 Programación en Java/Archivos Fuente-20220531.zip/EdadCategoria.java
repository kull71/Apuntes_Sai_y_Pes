import java.io.*;

public class EdadCategoria 
{

	
	 public static void main(String[] args)
	 {
	
		//Definimos el objeto br para leer lineas de la entrada
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		//Definimos variables nombre, edad y categoria dandole valores por 	defecto
		String nombre="";
		int edad=0;
		char categoria='A';
		
		//Iniciamos el bloque que podra producir errores
		try 
		{
				System.out.print("Introduzca su nombre: ");
				nombre = br.readLine();
				
				System.out.print("Introduzca su edad: ");
				edad=Integer.parseInt(br.readLine());
		}
		
			//capturamos cualquier excepcion que se pueda producir y la reportamos
		catch (Exception ex)
		{
			ex.printStackTrace(System.err);
			System.exit(-1);
		}
		
		//Como por defecto la categoria es A, revisamos si aumentamos a B o C
		if(edad>25)
			categoria='B';
		
		if(edad>50)
			categoria='C';
		
		//Imprimimos en pantalla la respuesta solicitada
		edad+=10;
		System.out.println("El usuario "+nombre+" de categoria "+categoria+" en una decada tendra "+edad+ " ");
		
		System.exit(0);
		
	 }//final de main
	
}
