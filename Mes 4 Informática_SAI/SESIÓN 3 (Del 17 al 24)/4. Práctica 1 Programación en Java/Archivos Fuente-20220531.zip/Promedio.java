
import java.io.*;

public class Promedio 
{
	public static void main(String[] args) 
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		double acumulador=0;
		
		for(int i=0;i<3;i++)
		{
			System.out.println("Ingrese el valor "+(i+1)+" de 3: ");
			acumulador=acumulador+=Double.parseDouble(leer(br));
			
		}
		
		double promedio = acumulador/3;
		
		System.out.println("Introduzca su nombre: ");
		String nombre=leer(br);
		System.out.printf("Usuario: "+nombre+" tu promedio es: %.2f ",promedio);
	}
	
	public static String leer(BufferedReader buff)
	{
		String lee="";
		try
		{
			lee=buff.readLine();
		}
		catch(Exception ex)
		{
			ex.printStackTrace(System.err);
		}
		return lee;
	}//final de la funcion leer
}//final de la clase
