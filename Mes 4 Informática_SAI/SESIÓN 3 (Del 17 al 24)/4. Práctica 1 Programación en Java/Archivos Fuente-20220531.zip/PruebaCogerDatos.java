import java.io.*;


public class PruebaCogerDatos 
{
	
		static double potencia (double a, int n) 
		{
			double res;
			
			if (n == 0)
				res = 1;
			else
				res = a * potencia(a, n - 1);
			
			return (res);
		}
			
		public static void main(String[] args) throws IOException
		{
				double num, resultado;
				int potencia;
						
				System.out.print("Introduzca base (real): ");
				num = CogerDatos.real();

				System.out.print("Introduzca la potencia: ");
				potencia = CogerDatos.entero();
				
				resultado = potencia(num, potencia);
				System.out.println("El resultado es: " + resultado);
				
		}
			
	}
