
import java.io.*;

public class Menor {

	public static void main(String[] args) 
	{
		int numero1 = 0;
		int numero2 = 0;
		int numero3 = 0;
		int menor;
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.print("Ingrese el primer numero: ");
		try 
		{
			numero1 = Integer.parseInt(br.readLine());
		}
		catch (IOException e) 
		{
			System.out.println("el programa se debe finalizar "+e);
			System.exit(-1);
		}
		catch (Exception e) 
		{
			System.out.println("Error imprevisto: " +e);
			System.exit(-1);
		}
		
		System.out.print("Ingrese el segundo numero: ");
		try 
		{
			numero2 = Integer.parseInt(br.readLine());
		}
		catch (IOException e) 
		{
			System.out.println("el programa se debe finalizar "+e);
			System.exit(-1);
		}
		catch (Exception e) 
		{
			System.out.println("Error imprevisto: "+e);
			System.exit(-1);
		}
		
		System.out.print("Ingrese el tercer numero: ");
		try 
		{
			numero3 = Integer.parseInt(br.readLine());
		}
		catch (IOException e) 
		{
			System.out.println("el programa se debe finalizar "+e);
			System.exit(-1);
		}
		catch (Exception e) 
		{
			System.out.println("Error imprevisto: "+e);
			System.exit(-1);
		}
		
		if (numero1 < numero2) 
		{
			menor = numero1;
		}
		else 
		{
			menor = numero2;
		}
		if (menor > numero3) 
		{
			menor = numero3;
		}
		
		System.out.println("El numero menor es: " + menor);
		System.out.println("El cuadrado es: " + menor * menor);
		System.out.println("El cubo es: " + menor * menor * menor);
	}
			
}
