
import java.util.Scanner;

public class Vocales {

		  
	    public static void main(String[] args) {
	  
	        Scanner sc = new Scanner(System.in);
	        
	        System.out.println("Introduce una frase");
	        String cadena= sc.nextLine();
	             
	        int contador=0;
	        for (int i=0;i<cadena.length();i++){
	            //Comprobamos si el caracter es una vocal
	            if(cadena.charAt(i)=='a' || 
	                    cadena.charAt(i)=='e' || 
	                    cadena.charAt(i)=='i' || 
	                    cadena.charAt(i)=='o' || 
	                    cadena.charAt(i)=='u'){
	                contador++;
	            }
	        }
	  
	        System.out.println("Hay "+contador+" vocales");
	        sc.close();
	    }

}
