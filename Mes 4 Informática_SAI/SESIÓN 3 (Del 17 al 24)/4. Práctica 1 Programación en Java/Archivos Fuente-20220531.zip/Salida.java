
import java.io.*;

public class Salida 
{

	public static void main(String[]argv) throws IOException
	{
		FileOutputStream os;
		OutputStreamWriter sw;
		BufferedWriter bw;
		int i;
		int max;
		os=new FileOutputStream("salida.txt");
		sw=new OutputStreamWriter(os);
		bw=new BufferedWriter(sw);
		
		max= Integer.parseInt(argv[0]);
		i=0;
		while(i<max)
		{
			bw.write("numero "+i+"\n");
			i=i+1;
		}
		bw.close();
	}
	
}
