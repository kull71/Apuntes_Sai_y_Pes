import java.io.*;

public class PromedioArray {


	public static void main(String[] args) 
		{
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			
			System.out.println("�Cu�ntas notas quiere introducir?" );
			int numeroNotas= Integer.parseInt(leer(br));
			double examenes []=new double [numeroNotas];
			System.out.println("Debe introducir: "+examenes.length+" notas.");
			
			double acumulador=0;
			
			for(int i=0;i<examenes.length;i++)
			{
				System.out.println("Introduzca el valor "+(i+1)+" de "+examenes.length+": ");
				examenes[i]=Double.parseDouble(leer(br));
				acumulador=acumulador+=examenes[i];

			}
			
			double promedio = acumulador/examenes.length;
			
			System.out.println("Introduzca su nombre: ");
			String nombre=leer(br);
			System.out.printf("Usuario: "+nombre+" tu promedio es: %.2f ",promedio);
		}
		
		public static String leer(BufferedReader buff)
		{
			String lee="";
			try
			{
				lee=buff.readLine();
			}
			catch(Exception ex)
			{
				ex.printStackTrace(System.err);
			}
			return lee;
		}//final de la funcion leer
	}//final de la clase