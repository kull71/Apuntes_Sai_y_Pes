

import java.util.StringTokenizer;

public class Token {

   public static void main(String[] args) 
   {
	  String frase;
      System.out.print("Introduce una frase: ");
      frase = CogerDatos.cadena();
      StringTokenizer st = new StringTokenizer(frase);
      System.out.println("Numero de palabras: " + st.countTokens());
      
   }

}
