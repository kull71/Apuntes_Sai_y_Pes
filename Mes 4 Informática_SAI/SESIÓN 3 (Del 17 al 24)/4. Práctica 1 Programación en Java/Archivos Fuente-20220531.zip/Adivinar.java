
import java.io.*;

public class Adivinar {

	public static void main(String[] args) 
	{
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

		int n, num;
		// n es el numero que hay que acertar
		// num guarda los numeros introducidos
		
		System.out.print("Introduce el numero a acertar: ");
		n = Integer.parseInt(leer(br));
		
		System.out.print("Introduce numero: ");
		num = Integer.parseInt(leer(br));
		while(num!=n) // mientras no coincidan ambos numeros
		{
			if(num>n)
				System.out.println("menor");
			else
				System.out.println("mayor");
		
			System.out.print("Introduce numero: ");
			num = Integer.parseInt(leer(br));
		
		}
		// al salir del mientras sabemos que num es igual a n
		System.out.println("Has acertado");
	}

	public static String leer(BufferedReader buff)
	{
		String lee="";
		try
		{
			lee=buff.readLine();
		}
		catch(Exception ex)
		{
			System.out.println("Error al leer "+ex);
			
		}
		return lee;
	}//final de la funcion leer
	
}
