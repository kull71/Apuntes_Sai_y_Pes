
import java.io.*;


public class Ecuacion
{


	public static double cogerNumeroDouble()
	{
		//Definimos el objeto br para leer lineas de la entrada
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

		int pedir=1;
		double num=0;
		while (pedir==1)
		{
			try
			{
				{
					num = Double.parseDouble(br.readLine());
					pedir=0;
				}
				
			}
			catch(Exception error)
			{
				System.out.println("Error. Vuelva a introducir el numero");
				pedir=1;
			}
		}
		
		return num;
	}
	
	public static void main(String[] args) 
	{
		double a,b,c; // coeficientes ax^2+bx+c=0
		double x1,x2,d; // soluciones y determinante
		
		System.out.println("Introduzca primer coeficiente (a):");
		a=cogerNumeroDouble();
		
		System.out.println("Introduzca segundo coeficiente: (b):");
		b=cogerNumeroDouble();
		
		System.out.println("Introduzca tercer coeficiente: (c):");
		c=cogerNumeroDouble();
		
		// calculamos el determinante
		d=((b*b)-4*a*c);
		if(d<0)
			System.out.println("No existen soluciones reales");
		else
		{
		// queda confirmar que a sea distinto de 0.
			// si a=0 nos encontramos una division por cero.
			x1=(-b+Math.sqrt(d))/(2*a);
			x2=(-b-Math.sqrt(d))/(2*a);
			System.out.println("Solucion: " + x1);
			System.out.println("Solucion: " + x2);
		}
	}
}
