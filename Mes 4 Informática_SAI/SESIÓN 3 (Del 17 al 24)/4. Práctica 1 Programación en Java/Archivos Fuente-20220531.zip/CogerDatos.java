
import java.io.*;

public class CogerDatos 
{
	static String inicializar()
	{
		String dato="";
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		try{
			dato=br.readLine();
		}
		catch(Exception e){
			System.out.append("Entrada incorrecta)");
		}
		return dato;
	}
	
	static int entero()
	{
		int valor=Integer.parseInt(inicializar());
		return valor;
	}
	
	static double real()
	{
		double valor=Double.parseDouble(inicializar());
		return valor;
	}
		
	static String cadena()
	{
		String valor=inicializar();
		return valor;
	}
	
	static char caracter()
	{
		String valor=inicializar();
		return valor.charAt(0);
	}

}
