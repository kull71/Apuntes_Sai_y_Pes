
import java.io.*;

public class Potencia 
{

	static double potencia (double a, int n) 
	{
		double res;
		
		if (n == 0)
			res = 1;
		else
			res = a * potencia(a, n - 1);
		
		return (res);
	}
		
	public static void main(String[] args) throws IOException
	{
			double num, resultado;
			int potencia;
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			
			System.out.print("Introduzca base (real): ");
			num = Double.parseDouble(br.readLine());

			System.out.print("Introduzca el exponente: ");
			potencia = Integer.parseInt(br.readLine());
			
			resultado = potencia(num, potencia);
			System.out.println("El resultado es: " + resultado);
			
	}
		
}
