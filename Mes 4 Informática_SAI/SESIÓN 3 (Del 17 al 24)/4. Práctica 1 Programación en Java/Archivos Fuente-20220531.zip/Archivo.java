
import java.io.*;

public class Archivo 
{
	public static void main(String[] arguments) throws IOException
	{
		FileInputStream fi;
		InputStreamReader sr;
		BufferedReader br;
		String lectura;

		if(arguments.length == 1)
		{
			fi = new FileInputStream(arguments[0]);
			sr = new InputStreamReader(fi);
			br = new BufferedReader(sr);
			lectura = br.readLine();
			
			while(lectura != null)
			{
				System.out.println(lectura);
				lectura = br.readLine();
			}
		}
	}
}
