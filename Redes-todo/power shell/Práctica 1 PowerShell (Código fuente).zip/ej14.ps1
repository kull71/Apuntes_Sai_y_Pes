﻿#Realizar un script utilizando el bucle for que muestre el siguiente patrón:
#  1
#  12
#  123
#  1234
#  12345

for ($i=1; $i -le 5; $i++)
{
	for ($j=1; $j -le $i; $j++)
	{
		Write-Host -NoNewline "$j"
	}
	Write-Host ""
} 
