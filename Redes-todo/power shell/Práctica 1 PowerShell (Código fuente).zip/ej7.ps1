﻿#Realizar un script que sume dos números que se pasan como argumento a la línea de comandos,
#y si no son pasados se devolverá error y se mostrará un mensaje indicando la forma de ejecutar el script.

#Si no se han pasado 2 parámetros muestra mensaje de error
if ($Args.count -ne 2)
{
	Write-Host "Uso: ${^} x y"
	Write-Host "donde x e y son dos números"
	
}

else{
    $suma=$Args[0]+$Args[1]
    Write-Host "La suma de "$Args[0]" y "$Args[1]" es $suma"
}
