﻿#Realizar un script que defina dos variables, a=20 y b=5. Muestra el resultado de la división de a entre b por pantalla.

$a=20
$b=5
$resultado= $a / $b
Write-Host $resultado 