﻿$x=15
Write-Host $x # O simplemente poniendo $x