﻿#Realizar un script que solicite al usuario dos números por teclado y los sume.

[int]$num1 = Read-Host "Introduzca el primer número: "
[int]$num2 = Read-Host "Introduzca el segundo número: "

$resultado = $num1+$num2

Write-Host "La suma de los dos números es: $resultado" 
