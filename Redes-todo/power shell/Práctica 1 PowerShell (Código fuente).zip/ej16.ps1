﻿#Realizar un script que muestre la tabla de multiplicar de un número pasado por parámetro

$i=0
while ($i -le 10)
{
	$resultado=$Args[0] * $i
	Write-Host ""$Args[0]"x$i = $resultado"
	$i++
}
