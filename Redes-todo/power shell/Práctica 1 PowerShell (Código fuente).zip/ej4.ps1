﻿Write-Host "Nombre Script: ${^}"
Write-Host "Nº de parámetros: "$Args.count""
Write-Host "Lista de los parámetros pasados: $Args"
Write-Host "Parametro 1: "$Args[0]""
Write-Host "Parametro 2: "$Args[1]""
Write-Host "Directorio home: $Home"
Write-Host "Directorio actual: $Pwd" 
 
