﻿#Realizar un script que muestre un mensaje de error si no se han pasado parámetros y 
#si se le han pasado parámetros que los muestre por pantalla.

if ($Args.count -eq 0 )
{
	Write-Host "ERROR: Ejecución sin parámetros"
}
else
{
      Write-Host "Lista de parámetros: $Args"
}
