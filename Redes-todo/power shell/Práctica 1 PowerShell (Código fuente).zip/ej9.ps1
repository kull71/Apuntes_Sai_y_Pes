﻿#Realizar un script que reciba un número por parámetro y, si es mayor que 100, muestre el mensaje "Número es mayor que 100".
#En caso contrario que muestre el mensaje “Número NO es mayor que 100”

if ([int]$Args[0] -gt 100)
{
	Write-Host ""$Args[0]" es mayor que 100"
}
else
{
	Write-Host ""$Args[0]"  NO es mayor que 100"
}
