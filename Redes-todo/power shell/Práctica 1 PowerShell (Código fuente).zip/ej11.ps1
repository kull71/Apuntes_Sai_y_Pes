﻿#Realizar un script que reciba dos números por parámetro y muestre un mensaje indicando si ambos números son iguales,
#si el primer número es mayor o si el segundo número es mayor.

#Si se ejecuta con el número de parámetros correcto
if ($Args.count -eq 2)
{
$num1 = [int]$Args[0]
$num2 = [int]$Args[1]

	if ($num1 -gt $num2)
	{
		Write-Host "$num1 es MAYOR que $num2"
    	}
	elseif ($num1 -eq $num2)
	{
		Write-Host "$num1 es IGUAL a $num2"
    	}
	else
	{
    		Write-Host "$num1 es MENOR que $num2"
	}
}
#Si se ejecuta con un número de parámetros incorrecto
else
{
  Write-Host "ERROR: Ejecución con número de parámetros incorrecto"
} 