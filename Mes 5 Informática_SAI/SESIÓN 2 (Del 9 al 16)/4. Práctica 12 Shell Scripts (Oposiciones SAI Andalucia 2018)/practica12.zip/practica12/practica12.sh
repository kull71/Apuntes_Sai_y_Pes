#!/bin/bash

###################INICIO DE DECLARACIÓN DE FUNCIONES####################

#Función que comprueba si el directorio ./arespaldar existe
#Si no existe el directorio se mostrará un error y finaliza
#la ejecución
compruebaDirectorio(){
	if [ ! -d "arespaldar" ]
	then
		echo "ERROR: No existe el directorio arespaldar" >> CSeg.log
		exit 1
	fi
}

#Función que comprueba si el directorio ./backups existe
#Si no existe el directorio se crea en ese momento
existeDirBackups(){
	if [ ! -d "backups" ]
	then
		echo "ADVERTENCIA: No existe el directorio backups" >> CSeg.log
		mkdir backups && echo "Directorio backups creado con éxito" >> CSeg.log
	fi
}


#Función que comprueba la fecha de la copia de seguridad
#más antigua. Si esta tiene más de 30 días se elimina
compruebaCopias(){
#Almacena la fecha más antigua de las copias de seguridad hechas
FECHA_MAS_ANTIGUA=$(ls -l backups/ --time-style=+%Y%m%d | tr -s " " | cut -d' ' -f6 | sort | tail -n +2 | head -1)
#Almacena la fecha de hace un mes
HACE_UN_MES=$(date --date "-1 month" +%Y%m%d)

if [ $FECHA_MAS_ANTIGUA -lt $HACE_UN_MES 2>/dev/null ]
then
	rm backups/$(ls -l backups/ --time-style=+%Y%m%d | tr -s " " | cut -d' ' -f7 | sort | tail -n +2 | head -1)
fi
}

#################FIN DE DECLARACIÓN DE FUNCIONES####################


#######################INICIO PROGRAMA PRINCIPAL####################
compruebaDirectorio
existeDirBackups
compruebaCopias

#Almacena la fecha actual
FECHA=$(date +%Y%m%d)

echo -e "\nCSeg$FECHA.tar.gz" >> CSeg.log
echo >> CSeg.log

tar -zcf backups/CSeg$FECHA.tar.gz arespaldar/ &>> CSeg.log && echo "Backup CSeg$FECHA.tar.gz creado con éxito" >> CSeg.log
